package com.example.smartmessmanager

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Member(var name:String,var phone:String,var rate:Double,var meals:Int=0,var paid:Double=0.0)
class MainActivity:Activity(){
 private val members=mutableListOf<Member>(); lateinit var list:LinearLayout; lateinit var dash:TextView
 private var lang="English"; private var pin="1234"; private val prefs by lazy{getSharedPreferences("mess",0)}

 override fun onCreate(b:Bundle?){super.onCreate(b);pin=prefs.getString("pin","1234")!!; login()}

 fun login(){
  val e=EditText(this);e.hint="4 digit PIN";e.inputType=2
  AlertDialog.Builder(this).setTitle("🔐 Smart Mess Manager").setMessage("Owner Login").setView(e)
   .setCancelable(false).setPositiveButton("Login"){_,_->if(e.text.toString()==pin)buildUI() else {Toast.makeText(this,"Wrong PIN",Toast.LENGTH_SHORT).show();login()}}
   .show()
 }
 fun buildUI(){
  val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(18,18,18,8)
  val title=TextView(this);title.text="🍱 Smart Mess Manager Pro";title.textSize=24f;title.setTextColor(Color.rgb(80,50,145));root.addView(title)
  dash=TextView(this);dash.textSize=15f;root.addView(dash)
  val menu=LinearLayout(this)
  fun b(t:String,f:()->Unit):Button{val x=Button(this);x.text=t;x.setOnClickListener{f()};menu.addView(x,LinearLayout.LayoutParams(0,-2,1f));return x}
  b("➕ Member"){addMember()};b("🍛 Meal"){meal()};b("📊 Report"){report()}
  root.addView(menu)
  val menu2=LinearLayout(this)
  b("🌐 Language"){language()};b("🔐 PIN"){changePin()};b("📅 New Month"){newMonth()}
  root.addView(menu2)
  val search=EditText(this);search.hint="🔎 Search member";root.addView(search)
  search.addTextChangedListener(object:android.text.TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){refresh(s.toString())};override fun afterTextChanged(e:android.text.Editable?){} })
  val wa=Button(this);wa.text="📱 WhatsApp Bill / Reminder";wa.setOnClickListener{chooseWhatsapp()};root.addView(wa)
  val sc=ScrollView(this);list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root);refresh("")
 }
 fun refresh(q:String){
  list.removeAllViews();var total=0.0;var paid=0.0;var meals=0
  members.filter{it.name.contains(q,true)||it.phone.contains(q)}.forEachIndexed{_,m->
   val bill=m.meals*m.rate;total+=bill;paid+=m.paid;meals+=m.meals
   val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(5,12,5,12)
   val t=TextView(this);t.text="${m.name}  |  ${m.phone}\n🍛 Meals: ${m.meals}   💰 Bill: ₹${bill.toInt()}\n💳 Paid: ₹${m.paid.toInt()}   🔴 Due: ₹${(bill-m.paid).toInt()}";t.textSize=16f;box.addView(t)
   val row=LinearLayout(this)
   val meal=Button(this);meal.text="+ Meal";meal.setOnClickListener{m.meals++;refresh(q)}
   val pay=Button(this);pay.text="Payment";pay.setOnClickListener{payment(m,q)}
   val wa=Button(this);wa.text="WhatsApp";wa.setOnClickListener{send(m)}
   val del=Button(this);del.text="Delete";del.setOnClickListener{members.remove(m);refresh(q)}
   row.addView(meal);row.addView(pay);row.addView(wa);row.addView(del);box.addView(row);list.addView(box)
  }
  dash.text="👥 ${members.size} Members   🍛 $meals Meals   💰 Bill ₹${total.toInt()}   💳 Collected ₹${paid.toInt()}   🔴 Pending ₹${(total-paid).toInt()}"
 }
 fun addMember(){
  val n=EditText(this);n.hint="Member name";val p=EditText(this);p.hint="WhatsApp number";val r=EditText(this);r.hint="Rate/meal ₹";r.inputType=2
  val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(25,0,25,0);l.addView(n);l.addView(p);l.addView(r)
  AlertDialog.Builder(this).setTitle("➕ Add Member").setView(l).setPositiveButton("Save"){_,_->members.add(Member(n.text.toString(),p.text.toString(),r.text.toString().toDoubleOrNull()?:80.0));refresh("")}.setNegativeButton("Cancel",null).show()
 }
 fun meal(){if(members.isEmpty()){addMember();return};AlertDialog.Builder(this).setTitle("🍛 Select Member").setItems(members.map{it.name}.toTypedArray()){_,i->members[i].meals++;refresh("")}.show()}
 fun payment(m:Member,q:String){
  val e=EditText(this);e.hint="Payment amount ₹";e.inputType=2
  AlertDialog.Builder(this).setTitle("💳 Record Payment").setView(e).setPositiveButton("Save"){_,_->m.paid+=e.text.toString().toDoubleOrNull()?:0.0;refresh(q)}.setNegativeButton("Cancel",null).show()
 }
 fun report(){
  val meals=members.sumOf{it.meals};val bill=members.sumOf{it.meals*it.rate};val paid=members.sumOf{it.paid}
  AlertDialog.Builder(this).setTitle("📊 Monthly Report").setMessage("Month: "+SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date())+"\n\nMembers: ${members.size}\nMeals: $meals\nTotal Bill: ₹${bill.toInt()}\nCollection: ₹${paid.toInt()}\nOutstanding: ₹${(bill-paid).toInt()}").setPositiveButton("OK",null).show()
 }
 fun chooseWhatsapp(){if(members.isEmpty())return;AlertDialog.Builder(this).setTitle("📱 Choose Member").setItems(members.map{it.name}.toTypedArray()){_,i->send(members[i])}.show()}
 fun send(m:Member){val bill=m.meals*m.rate;val msg="🍱 Smart Mess Manager Pro%0A%0AName: ${m.name}%0AMeals: ${m.meals}%0ABill: ₹${bill.toInt()}%0APaid: ₹${m.paid.toInt()}%0ADue: ₹${(bill-m.paid).toInt()}%0A%0APlease clear your pending amount. Thank you!"
  startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/${m.phone.replace("+","").replace(" ","")}?text=$msg")))}
 fun language(){val a=arrayOf("English","हिंदी","मराठी");AlertDialog.Builder(this).setTitle("Language").setItems(a){_,i->lang=a[i];Toast.makeText(this,"Language: $lang",Toast.LENGTH_SHORT).show()}.show()}
 fun changePin(){val e=EditText(this);e.hint="New 4 digit PIN";e.inputType=2;AlertDialog.Builder(this).setTitle("🔐 Change Owner PIN").setView(e).setPositiveButton("Save"){_,_->pin=e.text.toString();prefs.edit().putString("pin",pin).apply()}.setNegativeButton("Cancel",null).show()}
 fun newMonth(){AlertDialog.Builder(this).setTitle("📅 New Month").setMessage("Start a new month? Meal counts and payments will be reset.").setPositiveButton("Start"){_,_->members.forEach{it.meals=0;it.paid=0.0};refresh("")}.setNegativeButton("Cancel",null).show()}
}